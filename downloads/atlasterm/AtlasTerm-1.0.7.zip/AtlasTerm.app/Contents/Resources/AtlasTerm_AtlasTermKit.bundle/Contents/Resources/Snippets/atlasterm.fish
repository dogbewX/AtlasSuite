# AtlasTerm shell integration for fish (spec 27).
# Emits OSC 133 semantic-prompt marks (A prompt, B input, C command start, D;<exit> command end),
# a private OSC 9133;cmd=<base64>:cwd=<base64> payload before C, and OSC 7 after every cd.
# Harmless in other terminals. Source it from config.fish to use it without the AtlasTerm shim.
if status is-interactive; and not set -q ATLASTERM_SHELL_INTEGRATION
    set -gx ATLASTERM_SHELL_INTEGRATION 1

    function __atlasterm_b64
        printf '%s' $argv[1] | command base64 | command tr -d '\n'
    end

    function __atlasterm_osc7 --on-variable PWD
        printf '\e]7;file://%s%s\e\\\\' (hostname) (string escape --style=url -- $PWD)
    end

    function __atlasterm_prompt --on-event fish_prompt
        printf '\e]133;A\e\\\\'
        # Wrap the prompt once so the input mark follows it.
        if not functions -q __atlasterm_user_prompt; and functions -q fish_prompt
            functions -c fish_prompt __atlasterm_user_prompt
            function fish_prompt
                __atlasterm_user_prompt
                printf '\e]133;B\e\\\\'
            end
        end
    end

    function __atlasterm_preexec --on-event fish_preexec
        set -l cmd "$argv[1]"
        # Leading space: not logged, but still timed.
        if string match -q -- ' *' "$cmd"
            set cmd ''
        end
        printf '\e]9133;cmd=%s:cwd=%s\e\\\\' (__atlasterm_b64 "$cmd") (__atlasterm_b64 "$PWD")
        printf '\e]133;C\e\\\\'
        set -g __atlasterm_running 1
    end

    function __atlasterm_postexec --on-event fish_postexec
        set -l ret $status
        if set -q __atlasterm_running
            printf '\e]133;D;%s\e\\\\' $ret
            set -e __atlasterm_running
        end
    end

    __atlasterm_osc7
end
