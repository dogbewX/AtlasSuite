# AtlasTerm shell integration for zsh (spec 27).
# Emits OSC 133 semantic-prompt marks (A prompt, B input, C command start, D;<exit> command end),
# a private OSC 9133;cmd=<base64>:cwd=<base64> payload before C, and OSC 7 after every cd.
# Harmless in other terminals. Source it from ~/.zshrc to use it without the AtlasTerm shim.
[[ -o interactive ]] || return 0
[[ -n "${ATLASTERM_SHELL_INTEGRATION:-}" ]] && return 0
export ATLASTERM_SHELL_INTEGRATION=1

typeset -g __atlasterm_running=0

__atlasterm_b64() {
  printf '%s' "$1" | command base64 | command tr -d '\n'
}

__atlasterm_urlencode() {
  emulate -L zsh
  local LC_ALL=C s=$1 out= c i
  for (( i = 1; i <= ${#s}; i++ )); do
    c=$s[i]
    case $c in
      [-/._~A-Za-z0-9]) out+=$c ;;
      *) out+=$(printf '%%%02X' "'$c") ;;
    esac
  done
  print -rn -- "$out"
}

__atlasterm_osc7() {
  printf '\e]7;file://%s%s\e\\' "${HOST}" "$(__atlasterm_urlencode "$PWD")"
}

__atlasterm_precmd() {
  local ret=$?
  if (( __atlasterm_running )); then
    printf '\e]133;D;%s\e\\' "$ret"
    __atlasterm_running=0
  fi
  printf '\e]133;A\e\\'
  # Themes may rebuild PS1 every prompt; make sure the input mark is at its end.
  if [[ "$PS1" != *'133;B'* ]]; then
    PS1="${PS1}%{"$'\e]133;B\a'"%}"
  fi
}

__atlasterm_preexec() {
  local cmd=$1
  # Leading space: not logged (HIST_IGNORE_SPACE), but still timed.
  [[ "$cmd" == ' '* ]] && cmd=
  printf '\e]9133;cmd=%s:cwd=%s\e\\' "$(__atlasterm_b64 "$cmd")" "$(__atlasterm_b64 "$PWD")"
  printf '\e]133;C\e\\'
  __atlasterm_running=1
}

autoload -Uz add-zsh-hook
add-zsh-hook precmd __atlasterm_precmd
add-zsh-hook preexec __atlasterm_preexec
add-zsh-hook chpwd __atlasterm_osc7
__atlasterm_osc7
