# AtlasTerm shell integration for bash (spec 27).
# Emits OSC 133 semantic-prompt marks (A prompt, B input, C command start, D;<exit> command end),
# a private OSC 9133;cmd=<base64>:cwd=<base64> payload before C, and OSC 7 after every cd.
# Harmless in other terminals. Source it from ~/.bashrc to use it without the AtlasTerm shim.
# It exports ATLASTERM_SHELL_INTEGRATION, so nested shells skip it: the outer shell logs the command.
#
# Command text comes from history. A command that adds no history entry is logged without text: a
# leading-space command (HISTCONTROL=ignorespace) or one matched by HISTIGNORE. A repeat dropped by
# ignoredups/erasedups is told apart by matching $BASH_COMMAND against the previous entry, so it keeps
# its text. Limitation: a leading-space command that repeats the previous entry is logged with that text.
[[ $- == *i* ]] || return 0
[[ -n "${ATLASTERM_SHELL_INTEGRATION:-}" ]] && return 0
export ATLASTERM_SHELL_INTEGRATION=1

__atlasterm_running=
__atlasterm_at_prompt=
__atlasterm_histnum=
__atlasterm_histtext=
__atlasterm_last_pwd=

__atlasterm_b64() {
  printf '%s' "$1" | command base64 | command tr -d '\n'
}

__atlasterm_urlencode() {
  local LC_ALL=C s=$1 out= c i
  for (( i = 0; i < ${#s}; i++ )); do
    c=${s:i:1}
    case $c in
      [-/._~A-Za-z0-9]) out+=$c ;;
      *) out+=$(printf '%%%02X' "'$c") ;;
    esac
  done
  printf '%s' "$out"
}

__atlasterm_histline() {
  HISTTIMEFORMAT= builtin history 1
}

# DEBUG trap: runs before every simple command, so only the first one after a prompt counts.
__atlasterm_preexec() {
  [[ -n "$__atlasterm_at_prompt" ]] || return 0
  [[ -n "${COMP_LINE:-}" ]] && return 0
  # An empty line runs no command; the trap then fires for PROMPT_COMMAND itself.
  [[ "$BASH_COMMAND" == __atlasterm_prompt_start* ]] && return 0
  __atlasterm_at_prompt=
  local line num text cmd=
  line=$(__atlasterm_histline)
  # `history 1` prints "%5d%c %s": number, '*' or ' ', a space, then the line as typed.
  if [[ $line =~ ^[[:space:]]*([0-9]+)[*\ ]\ (.*)$ ]]; then
    num=${BASH_REMATCH[1]}
    text=${BASH_REMATCH[2]}
    if [[ "$num" != "$__atlasterm_histnum" || "$text" != "$__atlasterm_histtext" ]]; then
      cmd=$text
    elif [[ "$text" == "$BASH_COMMAND"* ]]; then
      # No new entry, but the command repeats the previous one (dropped as a duplicate).
      case ${HISTCONTROL:-} in *ignoredups*|*ignoreboth*|*erasedups*) cmd=$text ;; esac
    fi
    # Otherwise no new entry: a leading-space or HISTIGNOREd command — time it but log no text.
  fi
  [[ "$cmd" == ' '* ]] && cmd=
  printf '\e]9133;cmd=%s:cwd=%s\e\\' "$(__atlasterm_b64 "$cmd")" "$(__atlasterm_b64 "$PWD")"
  printf '\e]133;C\e\\'
  __atlasterm_running=1
}

__atlasterm_prompt_start() {
  local ret=$?
  __atlasterm_at_prompt=
  if [[ -n "$__atlasterm_running" ]]; then
    printf '\e]133;D;%s\e\\' "$ret"
    __atlasterm_running=
  fi
  if [[ "$PWD" != "$__atlasterm_last_pwd" ]]; then
    __atlasterm_last_pwd=$PWD
    printf '\e]7;file://%s%s\e\\' "${HOSTNAME}" "$(__atlasterm_urlencode "$PWD")"
  fi
  printf '\e]133;A\e\\'
  return $ret
}

__atlasterm_prompt_end() {
  local line
  line=$(__atlasterm_histline)
  __atlasterm_histnum= __atlasterm_histtext=
  if [[ $line =~ ^[[:space:]]*([0-9]+)[*\ ]\ (.*)$ ]]; then
    __atlasterm_histnum=${BASH_REMATCH[1]}
    __atlasterm_histtext=${BASH_REMATCH[2]}
  fi
  if [[ "$PS1" != *'133;B'* ]]; then
    PS1="${PS1}\[\e]133;B\e\\\\\]"
  fi
  __atlasterm_at_prompt=1
}

if [[ -n "${PROMPT_COMMAND:-}" ]]; then
  PROMPT_COMMAND="__atlasterm_prompt_start; ${PROMPT_COMMAND%;}; __atlasterm_prompt_end"
else
  PROMPT_COMMAND="__atlasterm_prompt_start; __atlasterm_prompt_end"
fi
trap '__atlasterm_preexec' DEBUG
