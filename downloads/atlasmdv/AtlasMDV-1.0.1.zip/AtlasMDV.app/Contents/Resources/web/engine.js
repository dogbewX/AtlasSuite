/* AtlasMDV rendering and export engine.
 *
 * Runs inside the app's WKWebView (and under Node for the engine tests).
 * Depends on three globals: marked, docx, PptxGenJS (and hljs when present).
 *
 *   AtlasMDV.render(markdown, baseHref)      -> { title }
 *   AtlasMDV.exportDocx(markdown, options)   -> Promise<base64 string>
 *   AtlasMDV.exportPptx(markdown, options)   -> Promise<base64 string>
 *   AtlasMDV.slidesFor(markdown, options)    -> [{ title, blocks }]   (pure, for tests)
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory;            // Node: require()(deps)
  } else {
    root.AtlasMDV = factory({ marked: root.marked, docx: root.docx, PptxGenJS: root.PptxGenJS, hljs: root.hljs });
  }
})(typeof self !== 'undefined' ? self : this, function (deps) {
  const { marked, docx, PptxGenJS, hljs } = deps;

  // ---------- Markdown parsing ----------

  function lexer() {
    return new marked.Lexer({ gfm: true, breaks: false });
  }

  function tokensFor(markdown) {
    return lexer().lex(markdown || '');
  }

  /** Plain text of an inline token list (links keep their text, images their alt). */
  function plainText(tokens) {
    if (!tokens) return '';
    if (typeof tokens === 'string') return tokens;
    return tokens.map((t) => {
      switch (t.type) {
        case 'text': case 'codespan': case 'escape': return t.tokens ? plainText(t.tokens) : unescapeHtml(t.text);
        case 'strong': case 'em': case 'del': case 'link': return plainText(t.tokens);
        case 'image': return t.text || '';
        case 'br': return '\n';
        case 'html': return '';
        default: return t.raw || '';
      }
    }).join('');
  }

  function unescapeHtml(s) {
    return String(s).replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  }

  /** Flattens inline tokens into runs: { text, bold, italic, code, strike, link } */
  function runsFor(tokens, style) {
    const out = [];
    const s = style || {};
    for (const t of tokens || []) {
      switch (t.type) {
        case 'text':
          if (t.tokens) out.push(...runsFor(t.tokens, s)); else out.push({ text: unescapeHtml(t.text), ...s });
          break;
        case 'escape': out.push({ text: unescapeHtml(t.text), ...s }); break;
        case 'strong': out.push(...runsFor(t.tokens, { ...s, bold: true })); break;
        case 'em': out.push(...runsFor(t.tokens, { ...s, italic: true })); break;
        case 'del': out.push(...runsFor(t.tokens, { ...s, strike: true })); break;
        case 'codespan': out.push({ text: unescapeHtml(t.text), ...s, code: true }); break;
        case 'link': out.push(...runsFor(t.tokens, { ...s, link: t.href })); break;
        case 'image': out.push({ text: t.text ? `[${t.text}]` : '[image]', ...s, italic: true }); break;
        case 'br': out.push({ text: '\n', ...s }); break;
        case 'html': case 'checkbox': break;
        default: out.push({ text: String(t.raw ?? t.text ?? ''), ...s });
      }
    }
    return out;
  }

  function firstHeading(tokens) {
    const h = tokens.find((t) => t.type === 'heading');
    return h ? plainText(h.tokens) : null;
  }

  // ---------- HTML rendering (viewer) ----------

  function html(markdown) {
    const renderer = new marked.Renderer();
    marked.use({ gfm: true });
    if (hljs) {
      marked.use({
        renderer: {
          code({ text, lang }) {
            const language = lang && hljs.getLanguage(lang) ? lang : null;
            const body = language ? hljs.highlight(text, { language }).value : hljs.highlightAuto(text).value;
            const cls = language ? ` class="hljs language-${language}"` : ' class="hljs"';
            return `<pre><code${cls}>${body}</code></pre>\n`;
          },
        },
      });
    }
    return marked.parse(markdown || '', { renderer });
  }

  function render(markdown, baseHref) {
    if (typeof document === 'undefined') return { title: firstHeading(tokensFor(markdown)) };
    let base = document.querySelector('base');
    if (!base) { base = document.createElement('base'); document.head.appendChild(base); }
    if (baseHref) base.setAttribute('href', baseHref);
    const body = document.getElementById('content') || document.body;
    body.innerHTML = html(markdown);
    // Task-list checkboxes stay read-only in a viewer.
    body.querySelectorAll('input[type=checkbox]').forEach((el) => { el.disabled = true; });
    return { title: firstHeading(tokensFor(markdown)) };
  }

  // ---------- DOCX ----------

  const DOCX_FONT = 'Helvetica Neue';
  const DOCX_MONO = 'Menlo';

  function docxRuns(tokens, style) {
    return runsFor(tokens, style).flatMap((r) => {
      const parts = r.text.split('\n');
      return parts.flatMap((p, i) => {
        const run = new docx.TextRun({
          text: p,
          bold: !!r.bold,
          italics: !!r.italic,
          strike: !!r.strike,
          font: r.code ? DOCX_MONO : undefined,
          shading: r.code ? { type: docx.ShadingType.CLEAR, fill: 'F2F2F2' } : undefined,
          color: r.link ? '0366D6' : undefined,
          underline: r.link ? {} : undefined,
          break: i > 0 ? 1 : undefined,
        });
        return r.link ? [new docx.ExternalHyperlink({ children: [run], link: r.link })] : [run];
      });
    });
  }

  function docxBlocks(tokens, ctx) {
    const out = [];
    for (const t of tokens) {
      switch (t.type) {
        case 'space': break;
        case 'heading':
          out.push(new docx.Paragraph({
            heading: [docx.HeadingLevel.HEADING_1, docx.HeadingLevel.HEADING_2, docx.HeadingLevel.HEADING_3,
              docx.HeadingLevel.HEADING_4, docx.HeadingLevel.HEADING_5, docx.HeadingLevel.HEADING_6][Math.min(t.depth, 6) - 1],
            children: docxRuns(t.tokens),
          }));
          break;
        case 'paragraph':
          out.push(new docx.Paragraph({ children: docxRuns(t.tokens), spacing: { after: 160 } }));
          break;
        case 'text':
          out.push(new docx.Paragraph({ children: docxRuns(t.tokens || [{ type: 'text', text: t.text }]) }));
          break;
        case 'blockquote':
          for (const sub of t.tokens) {
            if (sub.type === 'paragraph' || sub.type === 'text') {
              out.push(new docx.Paragraph({
                children: docxRuns(sub.tokens || [{ type: 'text', text: sub.text }], { italic: true }),
                indent: { left: 540 },
                border: { left: { style: docx.BorderStyle.SINGLE, size: 18, color: 'CCCCCC', space: 8 } },
                spacing: { after: 120 },
              }));
            } else out.push(...docxBlocks([sub], ctx));
          }
          break;
        case 'code':
          for (const line of (t.text || '').split('\n')) {
            out.push(new docx.Paragraph({
              children: [new docx.TextRun({ text: line || ' ', font: DOCX_MONO, size: 18 })],
              shading: { type: docx.ShadingType.CLEAR, fill: 'F6F8FA' },
              spacing: { before: 0, after: 0 },
            }));
          }
          out.push(new docx.Paragraph({ children: [], spacing: { after: 120 } }));
          break;
        case 'list':
          out.push(...docxList(t, 0, ctx));
          break;
        case 'table':
          out.push(docxTable(t));
          out.push(new docx.Paragraph({ children: [], spacing: { after: 120 } }));
          break;
        case 'hr':
          out.push(new docx.Paragraph({ children: [], border: { bottom: { style: docx.BorderStyle.SINGLE, size: 6, color: 'DDDDDD' } } }));
          break;
        case 'html': break;
        default:
          if (t.text) out.push(new docx.Paragraph({ children: [new docx.TextRun(unescapeHtml(t.text))] }));
      }
    }
    return out;
  }

  function docxList(list, level, ctx) {
    const out = [];
    for (const item of list.items) {
      const inline = [];
      const nested = [];
      for (const sub of item.tokens || []) {
        if (sub.type === 'list') nested.push(sub);
        else if (sub.type === 'checkbox' || sub.type === 'space') continue;
        else if (sub.type === 'text' || sub.type === 'paragraph') inline.push(...(sub.tokens || [{ type: 'text', text: sub.text || '' }]));
        else nested.push(sub);
      }
      const runs = docxRuns(inline);
      if (item.task) runs.unshift(new docx.TextRun({ text: item.checked ? '☑ ' : '☐ ' }));
      const para = list.ordered
        ? new docx.Paragraph({ children: runs, numbering: { reference: 'atlas-numbers', level: Math.min(level, 8) } })
        : new docx.Paragraph({ children: runs, bullet: { level: Math.min(level, 8) } });
      out.push(para);
      for (const n of nested) {
        if (n.type === 'list') out.push(...docxList(n, level + 1, ctx));
        else out.push(...docxBlocks([n], ctx));
      }
    }
    return out;
  }

  function docxTable(t) {
    const widthPct = 100;
    const headerRow = new docx.TableRow({
      tableHeader: true,
      children: t.header.map((cell) => new docx.TableCell({
        children: [new docx.Paragraph({ children: docxRuns(cell.tokens, { bold: true }) })],
        shading: { type: docx.ShadingType.CLEAR, fill: 'F0F0F0' },
      })),
    });
    const rows = t.rows.map((row) => new docx.TableRow({
      children: row.map((cell) => new docx.TableCell({ children: [new docx.Paragraph({ children: docxRuns(cell.tokens) })] })),
    }));
    return new docx.Table({ rows: [headerRow, ...rows], width: { size: widthPct, type: docx.WidthType.PERCENTAGE } });
  }

  async function exportDocx(markdown, options) {
    const opts = options || {};
    const tokens = tokensFor(markdown);
    const title = opts.title || firstHeading(tokens) || 'Document';
    const doc = new docx.Document({
      creator: 'AtlasMDV',
      title,
      styles: {
        default: { document: { run: { font: DOCX_FONT, size: 22 } } },
      },
      numbering: {
        config: [{
          reference: 'atlas-numbers',
          levels: [0, 1, 2, 3, 4, 5, 6, 7, 8].map((lvl) => ({
            level: lvl, format: docx.LevelFormat.DECIMAL, text: `%${lvl + 1}.`, alignment: docx.AlignmentType.START,
            style: { paragraph: { indent: { left: 720 * (lvl + 1), hanging: 360 } } },
          })),
        }],
      },
      sections: [{ children: docxBlocks(tokens, {}) }],
    });
    return docx.Packer.toBase64String(doc);
  }

  // ---------- PPTX ----------

  /**
   * Splits a document into slides. A heading at depth <= headingDepth starts a slide
   * (its text is the slide title); a horizontal rule starts a new untitled slide.
   * Content before the first heading becomes a leading slide titled `fallbackTitle`.
   */
  function slidesFor(markdown, options) {
    const opts = options || {};
    const depth = opts.headingDepth || 2;
    const tokens = tokensFor(markdown);
    const slides = [];
    let current = null;
    const open = (title) => { current = { title: title || '', blocks: [] }; slides.push(current); };
    for (const t of tokens) {
      if (t.type === 'space') continue;
      if (t.type === 'heading' && t.depth <= depth) { open(plainText(t.tokens)); continue; }
      if (t.type === 'hr') { open(''); continue; }
      if (!current) open(opts.fallbackTitle || firstHeading(tokens) || 'Slides');
      current.blocks.push(t);
    }
    // A slide that is only a title followed by another titled slide stays (section divider).
    return slides.filter((s) => s.title || s.blocks.length);
  }

  function pptxTextRuns(tokens, baseOpts) {
    return runsFor(tokens).map((r) => ({
      text: r.text,
      options: {
        ...baseOpts,
        bold: !!r.bold, italic: !!r.italic, strike: r.strike ? 'sngStrike' : undefined,
        fontFace: r.code ? 'Menlo' : (baseOpts && baseOpts.fontFace) || 'Helvetica Neue',
        hyperlink: r.link ? { url: r.link } : undefined,
      },
    }));
  }

  /** Flattens slide blocks to pptxgenjs text objects (one array = one text box). */
  function pptxBody(blocks) {
    const items = [];
    const push = (runs, extra) => {
      if (!runs.length) return;
      runs[0].options = { ...runs[0].options, ...(extra || {}), breakLine: false };
      runs[runs.length - 1].options = { ...runs[runs.length - 1].options, breakLine: true };
      items.push(...runs);
    };
    const walkList = (list, level) => {
      for (const item of list.items) {
        const inline = [], nested = [];
        for (const sub of item.tokens || []) {
          if (sub.type === 'list') nested.push(sub);
          else if (sub.type === 'checkbox' || sub.type === 'space') continue;
          else inline.push(...(sub.tokens || [{ type: 'text', text: sub.text || '' }]));
        }
        const runs = pptxTextRuns(inline);
        const bullet = list.ordered ? { type: 'number' } : true;
        const prefix = item.task ? (item.checked ? '☑ ' : '☐ ') : '';
        if (prefix && runs.length) runs[0].text = prefix + runs[0].text;
        push(runs, { bullet, indentLevel: level });
        for (const n of nested) walkList(n, level + 1);
      }
    };
    for (const b of blocks) {
      switch (b.type) {
        case 'heading': push(pptxTextRuns(b.tokens, { bold: true, fontSize: 20 })); break;
        case 'paragraph': case 'text': push(pptxTextRuns(b.tokens || [{ type: 'text', text: b.text }])); break;
        case 'blockquote': for (const sub of b.tokens) { if (sub.type === 'paragraph' || sub.type === 'text') push(pptxTextRuns(sub.tokens, { italic: true, color: '555555' })); } break;
        case 'code': push([{ text: b.text, options: { fontFace: 'Menlo', fontSize: 12, color: '333333' } }]); break;
        case 'list': walkList(b, 0); break;
        case 'table': break; // tables are drawn as real tables after the text
        case 'hr': case 'space': case 'html': break;
        default: if (b.text) push([{ text: unescapeHtml(b.text), options: {} }]);
      }
    }
    return items;
  }

  async function exportPptx(markdown, options) {
    const opts = options || {};
    const pptx = new PptxGenJS();
    pptx.layout = 'LAYOUT_16x9';
    pptx.author = 'AtlasMDV';
    const slides = slidesFor(markdown, opts);
    pptx.title = opts.title || (slides[0] && slides[0].title) || 'Slides';
    if (!slides.length) {
      pptx.addSlide().addText('Empty document', { x: 0.5, y: 2.5, w: 9, h: 1, fontSize: 24, align: 'center' });
    }
    const addTitle = (slide, text) => {
      slide.addText(text, { x: 0.5, y: 0.4, w: 9, h: 0.9, fontSize: 30, bold: true, fontFace: 'Helvetica Neue', color: '1F1F1F', valign: 'middle' });
      return 1.4;
    };
    const tableRows = (t) => [t.header.map((c) => ({ text: plainText(c.tokens), options: { bold: true, fill: { color: 'EFEFEF' } } }))]
      .concat(t.rows.map((r) => r.map((c) => plainText(c.tokens))));
    const SLIDE_BOTTOM = 5.3;
    for (const s of slides) {
      let slide = pptx.addSlide();
      let y = s.title ? addTitle(slide, s.title) : 0.4;
      const body = pptxBody(s.blocks);
      if (body.length) {
        // Size the body text by its line count instead of relying on autofit, which renders unevenly across apps.
        const lines = body.reduce((n, r) => n + (r.options && r.options.breakLine ? 1 : 0) + (r.text.match(/\n/g) || []).length, 0);
        const fontSize = lines <= 6 ? 18 : lines <= 10 ? 15 : lines <= 15 ? 12 : 10;
        const lineIn = (fontSize * 1.35) / 72;
        const bodyH = Math.min(SLIDE_BOTTOM - y, Math.max(0.5, lines * lineIn + 0.2));
        slide.addText(body, { x: 0.5, y, w: 9, h: bodyH, fontSize, fontFace: 'Helvetica Neue', color: '333333', valign: 'top', paraSpaceAfter: 4 });
        y += bodyH + 0.15;
      }
      for (const t of s.blocks.filter((b) => b.type === 'table')) {
        const rows = tableRows(t);
        const rowH = 0.35;
        const need = rowH * rows.length;
        if (y + need > SLIDE_BOTTOM) {
          slide = pptx.addSlide();
          y = s.title ? addTitle(slide, `${s.title} (cont.)`) : 0.4;
        }
        slide.addTable(rows, { x: 0.5, y, w: 9, rowH, fontSize: 12, fontFace: 'Helvetica Neue', border: { type: 'solid', color: 'CCCCCC', pt: 0.5 }, autoPage: false });
        y += need + 0.2;
      }
    }
    return pptx.write({ outputType: 'base64' });
  }

  return { render, html, tokensFor, plainText, runsFor, slidesFor, exportDocx, exportPptx, firstHeading };
});
