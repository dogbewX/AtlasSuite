/* Bridge between the Swift side and the engine.
 *
 * Swift calls (via evaluateJavaScript / callAsyncJavaScript):
 *   atlas.show(markdown, baseHref, fileName)  -> { title }
 *   atlas.exportDocx(options)                 -> base64 string (async)
 *   atlas.exportPptx(options)                 -> base64 string (async)
 *   atlas.setZoom(factor)
 *   atlas.scrollToTop()
 *
 * The page posts { event, ... } to the "atlas" message handler for things Swift
 * should know about (link clicks to external URLs, document title).
 */
(function () {
  let current = { markdown: '', fileName: '' };

  function post(msg) {
    try { window.webkit.messageHandlers.atlas.postMessage(msg); } catch (_) { /* not in WKWebView */ }
  }

  function show(markdown, baseHref, fileName) {
    current = { markdown: markdown || '', fileName: fileName || '' };
    const result = AtlasMDV.render(current.markdown, baseHref);
    document.body.classList.toggle('is-empty', !current.markdown.trim());
    post({ event: 'rendered', title: result.title || fileName || '' });
    return result;
  }

  function exportDocx(options) {
    return AtlasMDV.exportDocx(current.markdown, { title: titleFor(), ...(options || {}) });
  }

  function exportPptx(options) {
    return AtlasMDV.exportPptx(current.markdown, { title: titleFor(), fallbackTitle: current.fileName, ...(options || {}) });
  }

  function titleFor() {
    return AtlasMDV.firstHeading(AtlasMDV.tokensFor(current.markdown)) || current.fileName || 'Document';
  }

  function setZoom(factor) {
    document.documentElement.style.setProperty('--atlas-font-size', `${Math.round(16 * factor)}px`);
  }

  function scrollToTop() { window.scrollTo(0, 0); }

  // External links open in the default browser; in-page anchors scroll normally.
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (!href || href.startsWith('#')) return;
    const url = new URL(href, document.baseURI);
    if (url.protocol === 'http:' || url.protocol === 'https:' || url.protocol === 'mailto:') {
      e.preventDefault();
      post({ event: 'openExternal', url: url.href });
    } else if (url.protocol === 'file:' && /\.(md|markdown|mdown|mkd|txt)$/i.test(url.pathname)) {
      e.preventDefault();
      post({ event: 'openFile', url: url.href });
    }
  });

  window.atlas = { show, exportDocx, exportPptx, setZoom, scrollToTop };
  document.body.classList.add('is-empty');
  post({ event: 'ready' });
})();
